import Image from 'next/image'

const testimonials = [
  {
    content: "Our travel concierge made our honeymoon absolutely perfect. Every detail was taken care of, and we had experiences we never could have arranged on our own.",
    author: "Sarah & Tom",
    role: "Newlyweds"
  },
  {
    content: "As a busy executive, I don't have time to plan vacations. This service has been a game-changer, providing me with incredible trips tailored to my interests and schedule.",
    author: "Michael Chen",
    role: "CEO"
  },
  {
    content: "We've used this concierge service for family trips, and they always go above and beyond. They think of things we never would have considered, making each trip special.",
    author: "The Johnson Family",
    role: "Frequent Travelers"
  }
]

export default function Testimonials() {
  return (
    <section className="bg-white py-12 sm:py-16 lg:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">What Our Clients Say</h2>
          <p className="mt-4 text-lg text-gray-500">Don't just take our word for it - hear from some of our satisfied travelers</p>
        </div>

        <div className="mt-12 grid gap-8 lg:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="rounded-lg bg-gray-50 p-8">
              <blockquote>
                <p className="text-lg text-gray-700">&ldquo;{testimonial.content}&rdquo;</p>
              </blockquote>
              <div className="mt-6 flex items-center">
                <Image
                  className="h-12 w-12 rounded-full object-cover"
                  src={`/avatar-${index + 1}.jpg`}
                  alt={testimonial.author}
                  width={48}
                  height={48}
                />
                <div className="ml-4">
                  <p className="font-medium text-gray-900">{testimonial.author}</p>
                  <p className="text-sm text-gray-500">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

