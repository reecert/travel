import { Button } from "@/components/ui/button"

export default function Hero() {
  return (
    <section className="relative bg-[url('/hero-background.jpg')] bg-cover bg-center bg-no-repeat">
      <div className="absolute inset-0 bg-white/75 sm:bg-transparent sm:from-white/95 sm:to-white/25 sm:bg-gradient-to-r"></div>

      <div className="relative mx-auto max-w-screen-xl px-4 py-32 sm:px-6 lg:flex lg:h-screen lg:items-center lg:px-8">
        <div className="max-w-xl text-center sm:text-left">
          <h1 className="text-3xl font-extrabold sm:text-5xl">
            Your Personal
            <strong className="block font-extrabold text-primary">
              Travel Concierge
            </strong>
          </h1>

          <p className="mt-4 max-w-lg sm:text-xl/relaxed">
            Experience tailor-made journeys crafted by our expert travel concierges. Let us turn your travel dreams into unforgettable realities.
          </p>

          <div className="mt-8 flex flex-wrap gap-4 text-center">
            <Button size="lg">Book a Consultation</Button>
            <Button variant="outline" size="lg">Learn More</Button>
          </div>
        </div>
      </div>
    </section>
  )
}

